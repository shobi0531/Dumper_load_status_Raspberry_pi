import React from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import Content from './components/content/Content';
import Dumper from './dumper/Dumper';
import Shovel from './shovel/Shovel';
import Navbar from './sidebar/Navbar';
import DailyReport from './dailyreport/DailyReport';
import Tripdetails from './tripdetails/Tripdetails';

import Employee from './employee/Employee';

function App() {


  return (
    <div>
      {<Navbar />}
      <div>
        <Routes>
          <Route path="/content" element={<Content />} />
          <Route path="/dumperdetails" element={<Dumper />} />
          <Route path="/shovel" element={<Shovel />} />
          <Route path="/dailyreport" element={<DailyReport />} />
          <Route path="/trip" element={<Tripdetails />} />
          <Route path="/employee" element={<Employee />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
