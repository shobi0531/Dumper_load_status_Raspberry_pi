import React from "react";

import { BsFillTrashFill, BsFillPencilFill } from "react-icons/bs";

import "./DTable.css";

export const Table = ({ rows, deleteRow, editRow }) => {
  return (
    <div className="dtable-wrapper">
      <table className="dtable">
        <thead>
          <tr>
            <th>Dumper ID</th>
            <th className="dexpand">Dumper Name</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, idx) => {
            const statusText =
              row.status.charAt(0).toUpperCase() + row.status.slice(1);

            return (
              <tr key={idx}>
                <td>{row.dumperid}</td>
                <td className="dexpand">{row.dumpername}</td>
                <td>
                  <span className={`dlabel dlabel-${row.status}`}>
                    {statusText}
                  </span>
                </td>
                <td className="dfit">
                  <span className="dactions">
                    <BsFillTrashFill
                      className="ddelete-btn"
                      onClick={() => deleteRow(idx)}
                    />
                    <BsFillPencilFill
                      className="dedit-btn"
                      onClick={() => editRow(idx)}
                    />
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};