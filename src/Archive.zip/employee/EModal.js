// Modal.js
import React, { useState } from "react";
import "./EModal.css";

export const Modal = ({ closeModal, onSubmit }) => {
  const [formState, setFormState] = useState({
    EmployeeId: "",
    EmployeeName: "",
    employeeRole: "Dumper Operator", 
    status: "Active", // Updated: Status as the 4th column
  });
  const [errors, setErrors] = useState("");

  const validateForm = () => {
    if (
      formState.EmployeeId &&
      formState.EmployeeName &&
      formState.employeeRole &&
      formState.status
    ) {
      setErrors("");
      return true;
    } else {
      let errorFields = [];
      for (const [key, value] of Object.entries(formState)) {
        if (!value) {
          errorFields.push(key);
        }
      }
      setErrors(errorFields.join(", "));
      return false;
    }
  };

  const handleChange = (e) => {
    setFormState({ ...formState, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    onSubmit(formState);

    closeModal();
  };

  return (
    <div
      className="modal-container"
      onClick={(e) => {
        if (e.target.className === "modal-container") closeModal();
      }}
    >
      <div className="modal">
        <form>
          <div className="form-group">
            <label htmlFor="EmployeeId">Employee Id</label>
            <input
              name="EmployeeId"
              onChange={handleChange}
              value={formState.EmployeeId}
            />
          </div>
          <div className="form-group">
            <label htmlFor="EmployeeName">Employee Name</label>
            <input
              name="EmployeeName"
              onChange={handleChange}
              value={formState.EmployeeName}
            />
          </div>
          <div className="form-group">
            <label htmlFor="employeeRole">Employee Role</label>
            <select
              name="employeeRole"
              onChange={handleChange}
              value={formState.employeeRole}
            >
              <option value="Dumper Operator">Dumper Operator</option>
              <option value="Shovel Operator">Shovel Operator</option>
              {/* Add more roles as needed */}
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="status">Status</label>
            <select
              name="status"
              onChange={handleChange}
              value={formState.status}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
          {errors && (
            <div className="error">{`Please include: ${errors}`}</div>
          )}
          <button type="submit" className="btn" onClick={handleSubmit}>
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};
