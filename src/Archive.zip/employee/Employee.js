import React, { useState } from "react";
import "./Employee.css";
import { Table } from "./ETable";
import { Modal } from "./EModal";
import Header from "../components/header/Header";

function Employee() {
  const [modalOpen, setModalOpen] = useState(false);
  const [rows, setRows] = useState([
    {
      EmployeeId: "Employee ID",
      EmployeeName: "Employee Name",
      employeeRole: "Dumper Operator",
      status: "Active",
    },
    {
      EmployeeId: "Employee ID",
      EmployeeName: "Employee Name",
      employeeRole: "Dumper Operator",
      status: "Active",
    },
    {
      EmployeeId: "Employee ID",
      EmployeeName: "Employee Name",
      employeeRole: "Dumper Operator",
      status: "Inactive",
    }
  ]);
  const [rowToEdit, setRowToEdit] = useState(null);

  const handleDeleteRow = (targetIndex) => {
    setRows(rows.filter((_, idx) => idx !== targetIndex));
  };

  const handleEditRow = (idx) => {
    setRowToEdit(idx);

    setModalOpen(true);
  };

  const handleSubmit = (newRow) => {
    rowToEdit === null
      ? setRows([...rows, newRow])
      : setRows(
          rows.map((currRow, idx) => {
            if (idx !== rowToEdit) return currRow;

            return newRow;
          })
        );
  };

  return (
    <div className="employee">
        <Header pageTitle={'employeedetails'}/>
        <Table rows={rows} deleteRow={handleDeleteRow} editRow={handleEditRow} />
        <button onClick={() => setModalOpen(true)} className="btn">
          Add
        </button>
        {modalOpen && (
          <Modal
            closeModal={() => {
              setModalOpen(false);
              setRowToEdit(null);
            }}
            onSubmit={handleSubmit}
            defaultValue={rowToEdit !== null && rows[rowToEdit]}
          />
        )}
    </div>
  );
}

export default Employee;
