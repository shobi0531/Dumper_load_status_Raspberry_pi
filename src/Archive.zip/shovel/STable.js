import React from "react";

import { BsFillTrashFill, BsFillPencilFill } from "react-icons/bs";

import "./STable.css";

export const Table = ({ rows, deleteRow, editRow }) => {
  return (
    <div className="shtable-wrapper">
      <table className="shtable">
        <thead>
          <tr>
            <th>Shovel ID</th>
            <th className="shexpand">Shovel Name</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, idx) => {
            const statusText =
              row.status.charAt(0).toUpperCase() + row.status.slice(1);

            return (
              <tr key={idx}>
                <td>{row.shovelid}</td>
                <td className="shexpand">{row.shovelname}</td>
                <td>
                  <span className={`shlabel shlabel-${row.status}`}>
                    {statusText}
                  </span>
                </td>
                <td className="shfit">
                  <span className="shactions">
                    <BsFillTrashFill
                      className="shdelete-btn"
                      onClick={() => deleteRow(idx)}
                    />
                    <BsFillPencilFill
                      className="shedit-btn"
                      onClick={() => editRow(idx)}
                    />
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};