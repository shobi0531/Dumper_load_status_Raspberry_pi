// Modal.js
import React, { useState } from "react";

import "./Modal.css";

export const Modal = ({ closeModal, onSubmit, defaultValue }) => {
  const [formState, setFormState] = useState(
    defaultValue || {
      dumperId: "",
      shovel: "",
      date: "",
      inTime: "",
      outTime: "",
    }
  );
  const [errors, setErrors] = useState("");

  const validateForm = () => {
    const currentDate = new Date();
    const selectedDate = new Date(formState.date + 'T' + formState.outTime);

    if (
      formState.dumperId &&
      formState.shovel &&
      formState.date &&
      formState.inTime &&
      formState.outTime &&
      formState.inTime < formState.outTime &&
      selectedDate <= currentDate
    ) {
      setErrors("");
      return true;
    } else {
      setErrors("Please make sure Out Time is greater than In Time, Date is not in the future, and all fields are filled correctly");
      return false;
    }
  };

  const handleChange = (e) => {
    setFormState({ ...formState, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    onSubmit(formState);

    closeModal();
  };

  return (
    <div
      className="modal-container"
      onClick={(e) => {
        if (e.target.className === "modal-container") closeModal();
      }}
    >
      <div className="modal">
        <form>
          <div className="form-group">
            <label htmlFor="dumperId">Dumper Id</label>
            <input
              name="dumperId"
              onChange={handleChange}
              value={formState.dumperId}
            />
          </div>
          <div className="form-group">
            <label htmlFor="shovel">Shovel Id</label>
            <input
              name="shovel"
              onChange={handleChange}
              value={formState.shovel}
            />
          </div>
          <div className="form-group">
            <label htmlFor="date">Date</label>
            <input
              type="date"
              name="date"
              onChange={handleChange}
              value={formState.date}
            />
          </div>
          <div className="form-group">
            <label htmlFor="inTime">In Time</label>
            <input
              type="time"
              name="inTime"
              onChange={handleChange}
              value={formState.inTime}
            />
          </div>
          <div className="form-group">
            <label htmlFor="outTime">Out Time</label>
            <input
              type="time"
              name="outTime"
              onChange={handleChange}
              value={formState.outTime}
            />
          </div>
          {errors && <div className="error">{errors}</div>}
          <button type="submit" className="btn" onClick={handleSubmit}>
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};
