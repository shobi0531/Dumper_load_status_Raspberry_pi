// Table.js
import React from "react";
import { BsFillTrashFill, BsFillPencilFill } from "react-icons/bs";

import './TripTable.css'

export const Table = ({ rows, deleteRow, editRow }) => {
  return (
    <div className="ttable-wrapper">
      <table className="ttable">
        <thead>
          <tr>
            <th className="texpand"> Dumper Id</th>
            <th className="texpand">Shovel Id</th>
            <th >Date</th>
            <th >Time In</th>
            <th >Time Out</th>
            <th >Actions</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, idx) => {
            return (
              <tr key={idx}>
                <td className="texpand">{row.dumperId}</td>
                <td className="texpand">{row.shovel}</td>
                <td >{row.date}</td>
                <td >{row.inTime}</td>
                <td >{row.outTime}</td>
                <td className="tfit">
                  <span className="tactions">
                    <BsFillTrashFill
                      className="tdelete-btn"
                      onClick={() => deleteRow(idx)}
                    />
                    <BsFillPencilFill
                      className="tedit-btn"
                      onClick={() => editRow(idx)}
                    />
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
