import React,{ useState } from "react";

import "./Tripdetails.css";
import { Table } from "./TripTable";
import { Modal } from "./Modal";
import { Link } from "react-router-dom";
import PageHeader from "../components/header/Header";

function Tripdetails() {
  const [modalOpen, setModalOpen] = useState(false);
  const [rows, setRows] = useState([
    {
      dumperId: "Dumper ID",
      shovel: "Shovel ID",
      date:"2020-01-11",
      inTime: "10:00",
      outTime: "17:00",
    },
    {
      dumperId: "Dumper ID",
      shovel: "Shovel ID",
      date:"2020-01-12",
      inTime: "12:30",
      outTime: "18:30",
    },
    {
      dumperId: "Dumper ID",
      shovel: "Shovel ID",
      date:"2020-01-13",
      inTime: "16:45",
      outTime: "20:00",
    },
  ]);
  const [rowToEdit, setRowToEdit] = useState(null);

  const handleDeleteRow = (targetIndex) => {
    setRows(rows.filter((_, idx) => idx !== targetIndex));
  };

  const handleEditRow = (idx) => {
    setRowToEdit(idx);
    setModalOpen(true);
  };

  const handleSubmit = (newRow) => {
    rowToEdit === null
      ? setRows([...rows, newRow])
      : setRows(
          rows.map((currRow, idx) => {
            if (idx !== rowToEdit) return currRow;
            return newRow;
          })
        );
  };

  return (
    <div className="trip">
   <PageHeader pageTitle={'trip'} />
      <Link to='/report'>

        <Table rows={rows} deleteRow={handleDeleteRow} editRow={handleEditRow} />
        <button onClick={() => setModalOpen(true)} className="tbtn">
          Add
        </button>
        {modalOpen && (
          <Modal
            closeModal={() => {
              setModalOpen(false);
              setRowToEdit(null);
            }}
            onSubmit={handleSubmit}
            defaultValue={rowToEdit !== null && rows[rowToEdit]}
          />
        )}
      </Link>
    </div>
  );
}

export default Tripdetails;
